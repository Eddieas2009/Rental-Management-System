# Rental Management System
Designed in PHP and MySQL
